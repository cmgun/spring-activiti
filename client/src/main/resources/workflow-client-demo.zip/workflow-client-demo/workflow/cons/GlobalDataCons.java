package com.jdh.invoice.workflow.cons;

/**
 * 流程全局通用常量
 */
public interface GlobalDataCons {

    /**
     * 用户id
     */
    String USER_ID = "userId";

    /**
     * 用户名
     */
    String USER_NAME = "userName";

    /**
     * 企业编码
     */
    String ENT_CODE = "entCode";

    /**
     * 企业名称
     */
    String ENT_NAME = "entName";
}

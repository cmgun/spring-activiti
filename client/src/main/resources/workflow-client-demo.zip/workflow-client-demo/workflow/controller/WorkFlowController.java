package com.jdh.invoice.workflow.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.jdh.invoice.common.cons.PageCons;
import com.jdh.invoice.common.controller.SuperController;
import com.jdh.invoice.common.jwt.JwtUtil;
import com.jdh.invoice.common.responses.ResultResponse;
import com.jdh.invoice.enterprise.model.entity.Enterprise;
import com.jdh.invoice.enterprise.service.IEnterpriseService;
import com.jdh.invoice.workflow.enums.ProcessEnum;
import com.jdh.invoice.workflow.model.dto.ProcessCategoryDTO;
import com.jdh.invoice.workflow.model.dto.ProcessDetailDTO;
import com.jdh.invoice.workflow.model.dto.TaskListDTO;
import com.jdh.invoice.workflow.model.parm.TaskListPARM;
import com.jdh.invoice.workflow.service.IActIdentityService;
import com.jdh.invoice.workflow.service.IWorkFlowService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 流程相关 Controller
 *
 * @author chenqilin
 * @date 2019/8/21
 */
@Api(tags = {"流程相关接口"})
@RestController
@RequestMapping(value = "/flow")
@Validated
public class WorkFlowController extends SuperController {

    @Autowired
    private IWorkFlowService workFlowService;
    @Autowired
    private IEnterpriseService enterpriseService;
    @Autowired
    private IActIdentityService actIdentityService;

    @ApiOperation(value = "查询待办任务", notes = "当前登陆用户的待办任务查询")
    @ApiImplicitParams({
        @ApiImplicitParam(name = PageCons.PAGE_PAGE, value = "页数", paramType = "query"),
        @ApiImplicitParam(name = PageCons.PAGE_ROWS, value = "分页大小", paramType = "query")
    })
    @GetMapping("/todo")
    @RequiresAuthentication
    public ResultResponse<IPage<TaskListDTO>> getToDoList(TaskListPARM queryParm) {
        // 获取当前用户的组别
        List<String> candidateGroups = actIdentityService.getCurrentGroups();
        IPage<TaskListDTO> pageResult = workFlowService.getToDoList(candidateGroups, getPage(), queryParm);
        return success(pageResult);
    }

    @ApiOperation(value = "查询经办任务", notes = "当前登陆用户的经办任务查询")
    @ApiImplicitParams({
        @ApiImplicitParam(name = PageCons.PAGE_PAGE, value = "页数", paramType = "query"),
        @ApiImplicitParam(name = PageCons.PAGE_ROWS, value = "分页大小", paramType = "query")
    })
    @GetMapping("/history")
    @RequiresAuthentication
    public ResultResponse<IPage<TaskListDTO>> getHistoryList(TaskListPARM queryParm) {
        // 获取当前用户的组别
        List<String> candidateGroups = actIdentityService.getCurrentGroups();
        IPage<TaskListDTO> pageResult = workFlowService.getHistoryList(candidateGroups, getPage(), queryParm);
        return success(pageResult);
    }

    @ApiOperation(value = "查询指定流程id的流程任务", notes = "指定业务key的流程任务列表")
    @ApiImplicitParams({
        @ApiImplicitParam(name = "processId", value = "流程实例id", paramType = "query")
    })
    @GetMapping("/detail")
    @RequiresAuthentication
    public ResultResponse<ProcessDetailDTO> getProcessDetail(@RequestParam("processId") String processId) {
        ProcessDetailDTO processDetailDTO = workFlowService.getProcessDetail(processId);
        return success(processDetailDTO);
    }

    @ApiOperation(value = "查询流程业务类型列表", notes = "当前系统支持的流程中类型列表")
    @GetMapping("/cons/process-category")
    @RequiresAuthentication
    public ResultResponse<List<ProcessCategoryDTO>> getProcessCategory() {
        // 获取当前企业id，角色id
        // 获取当前登陆的用户和企业信息
        Long userId = JwtUtil.getCurrentUserId();
        Long entId = enterpriseService.getCurrentEntIdByUserId(userId);
        Enterprise enterprise = enterpriseService.getById(entId);
        List<ProcessCategoryDTO> processCategoryDTOList = ProcessEnum.getProcessCategoryByIdentity(enterprise.isMgt() ? "mgt" : "ent");
        return success(processCategoryDTOList);
    }
}

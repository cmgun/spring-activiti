package com.jdh.invoice.workflow.enums;

import com.fasterxml.jackson.annotation.JsonValue;
import org.apache.commons.lang3.StringUtils;

/**
 * 审批结果枚举，包含流程分支判断和权限表映射
 *
 * @author chenqilin
 * @date 2019/10/21
 */
public enum AuditResultEnum {

    /**
     * 暂存
     */
    SAVE("暂存，停留当前节点", "0"),
    /**
     * 通过
     */
    PASS("通过", "1"),

    /**
     * 结束流程
     */
    REJECT("拒绝", "2"),

    /**
     * 驳回之前的节点
     */
    LAST_NODE("驳回", "3");

    private final String name;

    private final String value;

    AuditResultEnum(String name, String value) {
        this.name = name;
        this.value = value;
    }

    public String getName() {
        return name;
    }

    @JsonValue
    public String getValue() {
        return value;
    }

    /**
     * 根据value查找
     * @param value
     * @return
     */
    public static String getNameByValue(String value) {
        if (StringUtils.isBlank(value)) {
            return "";
        }
        for (AuditResultEnum auditResultEnum : AuditResultEnum.values()) {
            if (StringUtils.equals(auditResultEnum.getValue(), value)) {
                return auditResultEnum.getName();
            }
        }
        return "";
    }
}

package com.jdh.invoice.workflow.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 额度申请流程定义，后续需要动态扩展则要保存到db中
 *
 * @author chenqilin
 * @date 2019/8/26
 */
public enum CreditApplyProcEnum {

    /**
     * 企业准入
     */
    @Deprecated
    ENTERPRISE_RISK("enterprise_risk", "企业准入"),
    /**
     * 额度初审
     */
    @Deprecated
    FIRST_APPROVE("credit_first_approve", "额度初审"),
    /**
     * 额度复审
     */
    @Deprecated
    SECOND_APPROVE("credit_second_approve", "额度复审"),

    /**
     * 准入初审
     */
    PLAT_FIRST_APPROVE("credit_platform_first_approve", "准入初审"),
    /**
     * 准入复审
     */
    PLAT_SECOND_APPROVE("credit_platform_second_approve", "准入复审"),

    /**
     * 风险初审
     */
    RISK_FIRST_APPROVE("risk_first_approve", "风险初审"),

    /**
     * 风险复审-1岗
     */
    RISK_SECOND_APPROVE_1("risk_second_approve_1", "风险复审-1岗"),

    /**
     * 风险复审-2岗
     */
    RISK_SECOND_APPROVE_2("risk_second_approve_2", "风险复审-2岗"),

    /**
     * 风险终审
     */
    RISK_THIRD_APPROVE("risk_third_approve", "风险终审"),

    /**
     * 担保人签约
     */
    AUTO_GURANTOR_SIGN("auto_gurantor_sign", "担保人签约");

    private final String value;

    private final String name;

    CreditApplyProcEnum(String value, String name) {
        this.value = value;
        this.name = name;
    }

    @JsonValue
    public String getValue() {
        return this.value;
    }

    public String getName() {
        return name;
    }
}

package com.jdh.invoice.workflow.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.baomidou.mybatisplus.core.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 下个节点权限身份类型
 */
public enum IdentityTypeEnum implements IEnum<Integer> {

    /**
     * 参与用户组
     */
    CANDIDATE_GROUPS(0);


    @EnumValue
    private final int value;

    IdentityTypeEnum(final int value) {
        this.value = value;
    }

    @JsonValue
    @Override
    public Integer getValue() {
        return this.value;
    }
}

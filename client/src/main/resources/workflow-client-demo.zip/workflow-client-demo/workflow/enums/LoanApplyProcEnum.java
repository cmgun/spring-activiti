package com.jdh.invoice.workflow.enums;

import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 放款申请流程定义，后续需要动态扩展则要保存到db中
 *
 * @author chenqilin
 * @date 2019/8/26
 */
public enum LoanApplyProcEnum {

    /**
     * 融资企业复核
     */
    ENT_APPROVE("loan_ent_approve", "融资企业复核"),

    /**
     * 平台初审
     */
    PLAT_FIRST_APPROVE("loan_platform_first_approve", "平台初审"),

    /**
     * 融资企业复核
     */
    PLAT_SECOND_APPROVE("loan_platform_second_approve", "平台复审");

    private final String value;

    private final String name;

    LoanApplyProcEnum(String value, String name) {
        this.value = value;
        this.name = name;
    }

    @JsonValue
    public String getValue() {
        return this.value;
    }

    public String getName() {
        return name;
    }
}

package com.jdh.invoice.workflow.enums;

import com.baomidou.mybatisplus.annotation.EnumValue;
import com.baomidou.mybatisplus.core.enums.IEnum;
import com.fasterxml.jackson.annotation.JsonValue;

/**
 * 当前节点定义类型
 */
public enum NodeDefTypeEnum implements IEnum<Integer> {

    /**
     * 流程
     */
    PROCESS(0),

    /**
     * 任务
     */
    TASK(1);


    @EnumValue
    private final int value;

    NodeDefTypeEnum(final int value) {
        this.value = value;
    }

    @JsonValue
    @Override
    public Integer getValue() {
        return this.value;
    }
}

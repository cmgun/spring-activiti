package com.jdh.invoice.workflow.enums;

import com.fasterxml.jackson.annotation.JsonValue;
import com.google.common.collect.Lists;
import com.jdh.invoice.workflow.model.dto.ProcessCategoryDTO;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

/**
 * 流程信息定义
 *
 * @author chenqilin
 * @date 2019/8/26
 */
public enum ProcessEnum {

    /**
     * 发票融资-额度申请
     */
    INVOICE_CREDIT_APPLY("01-invoice-creditApply", "credit-apply", "额度申请", "mgt"),

    /**
     * 发票融资-放款申请
     */
    INVOICE_LOAN_APPLY("01-invoice-loanApply", "loan-apply", "提款申请", "ent,mgt");

    /**
     * 流程类别，即流程namespace
     */
    private final String category;

    /**
     * 流程定义id
     */
    private final String defId;

    /**
     * 名称
     */
    private final String name;

    /**
     * 流程权限可见性，ent-企业端可见，mgt-运营端可见
     */
    private final String identity;

    ProcessEnum(String category, String defId, String name, String identity) {
        this.category = category;
        this.defId = defId;
        this.name = name;
        this.identity = identity;
    }

    @JsonValue
    public String getCategory() {
        return category;
    }

    public String getDefId() {
        return defId;
    }

    public String getName() {
        return name;
    }

    public String getIdentity() {
        return identity;
    }

    /**
     * 根据权限获取可见的流程类别
     *
     * @param identity
     * @return
     */
    public static List<ProcessCategoryDTO> getProcessCategoryByIdentity(String identity) {
        List<ProcessCategoryDTO> processCategoryList = Lists.newArrayList();
        for (ProcessEnum processEnum : ProcessEnum.values()) {
            if (processEnum.getIdentity().contains(identity)) {
                ProcessCategoryDTO category = new ProcessCategoryDTO();
                category.setProcCategory(processEnum.getCategory());
                category.setName(processEnum.getName());
                processCategoryList.add(category);
            }
        }
        return processCategoryList;
    }

    /**
     * 根据流程定义id获取展示名称
     *
     * @param defId
     * @return
     */
    public static String getNameByDefId(String defId) {
        for (ProcessEnum processEnum : ProcessEnum.values()) {
            if (StringUtils.equals(processEnum.getDefId(), defId)) {
                return processEnum.getName();
            }
        }
        return "";
    }

    /**
     * 根据流程定义id获取展示名称
     *
     * @param category
     * @return
     */
    public static String getNameByCategory(String category) {
        for (ProcessEnum processEnum : ProcessEnum.values()) {
            if (StringUtils.equals(processEnum.getCategory(), category)) {
                return processEnum.getName();
            }
        }
        return "";
    }
}

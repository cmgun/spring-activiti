package com.jdh.invoice.workflow.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.jdh.invoice.workflow.model.entity.ActIdentity;
import org.apache.ibatis.annotations.Mapper;

/**
 * 流程任务节点权限 Mapper
 *
 * @author chenqilin
 * @date 2019/8/20
 */
@Mapper
public interface ActIdentityMapper extends BaseMapper<ActIdentity> {
}

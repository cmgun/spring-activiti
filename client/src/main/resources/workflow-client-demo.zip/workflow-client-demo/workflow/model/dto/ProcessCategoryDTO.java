package com.jdh.invoice.workflow.model.dto;

import io.swagger.annotations.ApiModel;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 流程类型
 *
 * @author chenqilin
 * @date 2019/10/17
 */
@ApiModel
@Data
@EqualsAndHashCode(callSuper = false)
public class ProcessCategoryDTO {

    private String procCategory;

    private String name;
}

package com.jdh.invoice.workflow.model.dto;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 指定流程详情 DTO
 *
 * @author chenqilin
 * @date 2019/8/26
 */
@ApiModel
@Data
@EqualsAndHashCode(callSuper = false)
public class ProcessDetailDTO {

    @ApiModelProperty("流程id")
    private String processId;

    @ApiModelProperty("任务状态是否激活中")
    private Boolean isActive;

    @ApiModelProperty("当前处理角色")
    private String currentGroups;

    @ApiModelProperty("历史任务列表")
    private List<ProcessHistoryDTO> history;
}

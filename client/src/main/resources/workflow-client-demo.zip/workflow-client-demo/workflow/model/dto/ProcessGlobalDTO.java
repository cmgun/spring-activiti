package com.jdh.invoice.workflow.model.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 流程通用信息
 *
 * @author chenqilin
 * @date 2019/8/21
 */
@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class ProcessGlobalDTO {

    @ApiModelProperty("流程发起人id")
    private Long userId;

    @ApiModelProperty("流程发起人姓名")
    private String userName;

    @ApiModelProperty("流程发起人所属企业编码")
    private String entCode;

    @ApiModelProperty("流程发起人所属企业名称")
    private String entName;
}

package com.jdh.invoice.workflow.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jdh.fuhsi.api.model.History;
import com.jdh.invoice.workflow.cons.GlobalDataCons;
import com.jdh.invoice.workflow.enums.AuditResultEnum;
import com.jdh.invoice.workflow.utils.WorkFlowUtils;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * 指定流程详细任务列表 DTO
 *
 * @author chenqilin
 * @date 2019/8/26
 */
@ApiModel
@Data
@EqualsAndHashCode(callSuper = false)
public class ProcessHistoryDTO {

    @ApiModelProperty("任务编号")
    private String taskId;

    @ApiModelProperty("任务名称")
    private String taskName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty("操作时间")
    private Date operateTime;

    @ApiModelProperty("操作者id")
    private Long operatorId;

    @ApiModelProperty(value = "操作者名称")
    private String operatorName;

    @ApiModelProperty(value = "审批结果", notes = "只有审批结束的任务才有值，流程中任务为空")
    private String operateResult;

    @ApiModelProperty("备注")
    private String comment;

    public ProcessHistoryDTO(History history, List<String> activeTaskIds) {
        this.taskId = history.getTaskId();
        this.taskName = history.getTaskName();
        if (history.getAuditTime() == null) {
            // 没有结束的任务
            this.operateTime = history.getCreateTime();
            LinkedHashMap<String, Object> data = (LinkedHashMap<String, Object>) history.getData();
            this.operatorId = Long.valueOf(data.get(GlobalDataCons.USER_ID).toString());
            this.operatorName = (String) data.get(GlobalDataCons.USER_NAME);
            // 后续用于查询进行中处理人的信息
            activeTaskIds.add(history.getTaskId());
        } else {
            // 已结束任务
            this.operateTime = history.getAuditTime();
            this.operatorId = history.getAuditor() != null ? Long.valueOf(history.getAuditor()) : null;
            this.operatorName = history.getAuditorName();
            this.operateResult = history.getAuditResult() == null ? "" : AuditResultEnum.getNameByValue(String.valueOf(history.getAuditResult()));
            this.comment = WorkFlowUtils.getHistoryComment(history.getComments());
        }
    }
}

package com.jdh.invoice.workflow.model.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.jdh.fuhsi.api.model.History;
import com.jdh.fuhsi.api.model.Task;
import com.jdh.invoice.workflow.cons.GlobalDataCons;
import com.jdh.invoice.workflow.enums.ProcessEnum;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.Date;
import java.util.LinkedHashMap;

/**
 * 流程任务列表 DTO
 *
 * @author chenqilin
 * @date 2019/8/21
 */
@ApiModel
@Data
@EqualsAndHashCode(callSuper = false)
public class TaskListDTO {

    @ApiModelProperty("任务编号")
    private String taskId;

    @ApiModelProperty("任务名称")
    private String taskName;

    @ApiModelProperty("所属流程id")
    private String processId;

    @ApiModelProperty("业务编号")
    private String businessKey;

    @ApiModelProperty("流程发起人id")
    private Long userId;

    @ApiModelProperty("流程发起人姓名")
    private String userName;

    @ApiModelProperty("流程发起人所属企业编码")
    private String entCode;

    @ApiModelProperty("流程发起人所属企业名称")
    private String entName;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("任务类别")
    private String taskDefKey;

    @ApiModelProperty("业务种类名称")
    private String procCategory;

    @ApiModelProperty("任务是否激活，结束-1，未结束-0")
    private Boolean isActive;

    public TaskListDTO(Task task, boolean isActive) {
        this.taskId = task.getTaskId();
        this.taskName = task.getTaskName();
        this.businessKey = task.getBusinessKey();
        this.processId = task.getProcessInstanceId();
        this.createTime = task.getCreateTime();
        this.procCategory = ProcessEnum.getNameByDefId(task.getProcessDefinitionKey());
        this.taskDefKey = task.getTaskDefKey();
        this.isActive = isActive;
        LinkedHashMap<String, Object> data = (LinkedHashMap<String, Object>) task.getData();
        this.userId = Long.valueOf(data.get(GlobalDataCons.USER_ID).toString());
        this.userName = (String) data.get(GlobalDataCons.USER_NAME);
        this.entCode = (String) data.get(GlobalDataCons.ENT_CODE);
        this.entName = (String) data.get(GlobalDataCons.ENT_NAME);
    }

    public TaskListDTO(History history) {
        this.taskId = history.getTaskId();
        this.taskName = history.getTaskName();
        this.businessKey = history.getBusinessKey();
        this.processId = history.getProcessInstanceId();
        this.createTime = history.getCreateTime();
        this.procCategory = ProcessEnum.getNameByCategory(history.getProcNameSpace());
        this.taskDefKey = history.getTaskDefKey();
        this.isActive = history.getAuditTime() == null;
        LinkedHashMap<String, Object> data = (LinkedHashMap<String, Object>) history.getData();
        this.userId = Long.valueOf(data.get(GlobalDataCons.USER_ID).toString());
        this.userName = (String) data.get(GlobalDataCons.USER_NAME);
        this.entCode = (String) data.get(GlobalDataCons.ENT_CODE);
        this.entName = (String) data.get(GlobalDataCons.ENT_NAME);
    }
}

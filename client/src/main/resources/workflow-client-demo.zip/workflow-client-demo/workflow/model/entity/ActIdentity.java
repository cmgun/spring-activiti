package com.jdh.invoice.workflow.model.entity;

import java.time.LocalDateTime;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import com.jdh.invoice.common.converter.Convert;
import com.jdh.invoice.workflow.enums.IdentityTypeEnum;
import com.jdh.invoice.workflow.enums.NodeDefTypeEnum;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * 流程任务节点权限
 */
@Data
@Builder
@EqualsAndHashCode(callSuper = false)
@TableName("act_identity")
public class ActIdentity extends Convert {

    private static final long serialVersionUID = 7090743216724531222L;
    /**
     * 主键
     */
    @TableId(type = IdType.AUTO)
    private Long id;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 当前节点标识，可以是任务定义id，流程定义id
     */
    private String currentDefId;

    /**
     * 当前节点名称
     */
    private String defName;

    /**
     * 当前节点定义类型
     */
    private NodeDefTypeEnum defType;

    /**
     * 下个节点权限身份类型
     */
    private IdentityTypeEnum identityType;

    /**
     * 下个节点权限身份值
     */
    private String identityValue;

    /**
     * 节点子id
     */
    private String defSubId;
}

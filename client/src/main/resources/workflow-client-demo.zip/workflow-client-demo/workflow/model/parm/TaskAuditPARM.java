package com.jdh.invoice.workflow.model.parm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

/**
 * 任务审批参数
 *
 * @author chenqilin
 * @date 2019/8/23
 */
@ApiModel
@Data
@Builder
@EqualsAndHashCode(callSuper = false)
public class TaskAuditPARM {

    @ApiModelProperty("任务id")
    private String taskId;

    @ApiModelProperty("参与用户组")
    private List<String> candidateGroups;

    @ApiModelProperty("审批结果")
    private Object auditResult;

    @ApiModelProperty("审批意见")
    private String comment;
}

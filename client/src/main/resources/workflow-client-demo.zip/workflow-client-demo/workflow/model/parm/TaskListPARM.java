package com.jdh.invoice.workflow.model.parm;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

/**
 * 流程任务列表查询条件
 *
 * @author chenqilin
 * @date 2019/8/21
 */
@ApiModel
@Data
@NoArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class TaskListPARM {

    @ApiModelProperty("任务编号")
    private String taskId;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间查询开始日期，yyyy-MM-dd HH:mm:ss")
    private Date createTimeStart;

    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty("创建时间查询结束日期，yyyy-MM-dd HH:mm:ss")
    private Date createTimeEnd;

    @ApiModelProperty("流程类别")
    private String procCategory;

    @ApiModelProperty("是否激活的任务，激活-1，未激活/结束-0")
    private Boolean active;

}

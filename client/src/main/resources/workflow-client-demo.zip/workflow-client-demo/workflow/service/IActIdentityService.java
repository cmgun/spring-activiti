package com.jdh.invoice.workflow.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.jdh.invoice.workflow.enums.NodeDefTypeEnum;
import com.jdh.invoice.workflow.model.entity.ActIdentity;

import java.util.List;

/**
 * 流程任务节点权限 服务接口
 *
 * @author chenqilin
 * @date 2019/8/20
 */
public interface IActIdentityService extends IService<ActIdentity> {

    /**
     * 查询流程下个节点的身份权限
     *
     * @param currentDefId 当前节点定义id
     * @param nodeDefType 当前节点类型
     * @return 下个节点的身份权限
     */
    List<ActIdentity> queryNextNodeIdentity(String currentDefId, NodeDefTypeEnum nodeDefType);

    /**
     * 获取当前登陆用户所属的参与组
     * @return
     */
    List<String> getCurrentGroups();
}

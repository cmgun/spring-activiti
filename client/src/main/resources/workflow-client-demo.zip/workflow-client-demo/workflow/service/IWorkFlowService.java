package com.jdh.invoice.workflow.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.jdh.fuhsi.api.common.Response;
import com.jdh.fuhsi.api.model.History;
import com.jdh.fuhsi.api.model.Process;
import com.jdh.fuhsi.api.model.Task;
import com.jdh.invoice.workflow.enums.ProcessEnum;
import com.jdh.invoice.workflow.model.dto.ProcessDetailDTO;
import com.jdh.invoice.workflow.model.dto.ProcessGlobalDTO;
import com.jdh.invoice.workflow.model.dto.TaskListDTO;
import com.jdh.invoice.workflow.model.entity.ActIdentity;
import com.jdh.invoice.workflow.model.parm.TaskAuditPARM;
import com.jdh.invoice.workflow.model.parm.TaskListPARM;

import java.util.List;

/**
 * 流程引擎通用服务接口
 *
 * @author chenqilin
 * @date 2019/8/20
 */
public interface IWorkFlowService {

    /**
     * 流程开启
     *
     * @param businessKey 业务key
     * @param processGlobalDTO 流程通用上下文
     * @param processEnum 流程信息
     * @param identity 下个节点的权限信息
     * @return 流程信息
     */
    Response<Process> startProcess(String businessKey, ProcessGlobalDTO processGlobalDTO, ProcessEnum processEnum, ActIdentity identity);

    /**
     * 终止流程
     * @param processInstanceId 流程实例id
     * @param reason 终止原因
     */
    Response<Void> endProcess(String processInstanceId, String reason);

    /**
     * 获取流程激活的任务
     * @param businessKey 业务key
     * @param processDefinitionKey 流程定义id
     * @return 激活的任务
     */
    List<Task> getActiveTaskByBusinessKey(String businessKey, String processDefinitionKey);

    /**
     * 查询待办任务
     *
     * @param candidateGroups 用户组
     * @param page 分页信息
     * @param queryParm 查询条件
     */
    Page<TaskListDTO> getToDoList(List<String> candidateGroups, Page<TaskListDTO> page, TaskListPARM queryParm);

    /**
     * 自动审批待办任务
     * @param procCategory
     * @param taskDefKey
     * @param page
     * @return
     */
    List<TaskListDTO> getAutoToDoList(String procCategory, String taskDefKey, Page page);

    /**
     * 查询经办任务
     *
     * @param candidateGroups 用户组
     * @param page            分页信息
     * @param queryParm       查询条件
     */
    Page<TaskListDTO> getHistoryList(List<String> candidateGroups, Page<TaskListDTO> page, TaskListPARM queryParm);

    /**
     * 查询流程详情
     */
    ProcessDetailDTO getProcessDetail(String processId);

    /**
     * 任务审批
     *
     * @param taskAuditPARM 任务审批参数
     * @param identity 下个任务节点权限信息
     * @param isAutoTask 是否自动审批任务
     * @return 响应结果
     */
    Response auditTask(TaskAuditPARM taskAuditPARM, ActIdentity identity, boolean isAutoTask);

    /**
     * 查询历史任务详情
     *
     * @param taskId 任务id
     * @return 历史任务详情
     */
    History queryHistoryDetail(String taskId);

    /**
     * 查询激活任务详情
     *
     * @param taskId 任务id
     * @return 任务详情
     */
    Task queryTaskDetail(String taskId);
}

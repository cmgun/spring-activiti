package com.jdh.invoice.workflow.service.impl;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.jdh.invoice.common.jwt.JwtUtil;
import com.jdh.invoice.enterprise.model.entity.Enterprise;
import com.jdh.invoice.enterprise.service.IEnterpriseService;
import com.jdh.invoice.user.service.IUserService;
import com.jdh.invoice.workflow.enums.NodeDefTypeEnum;
import com.jdh.invoice.workflow.mapper.ActIdentityMapper;
import com.jdh.invoice.workflow.model.entity.ActIdentity;
import com.jdh.invoice.workflow.service.IActIdentityService;
import com.jdh.invoice.workflow.utils.WorkFlowUtils;

import lombok.extern.slf4j.Slf4j;

/**
 * 流程任务节点权限服务
 *
 * @author chenqilin
 * @date 2019/8/20
 */
@Slf4j
@Service
public class ActIdentityServiceImpl extends ServiceImpl<ActIdentityMapper, ActIdentity> implements IActIdentityService {

    @Autowired
    private IEnterpriseService enterpriseService;
    @Autowired
    private IUserService userService;

    @Override
    public List<ActIdentity> queryNextNodeIdentity(String currentDefId, NodeDefTypeEnum nodeDefType) {
        return this.lambdaQuery()
            .eq(ActIdentity::getCurrentDefId, currentDefId)
            .eq(ActIdentity::getDefType, nodeDefType)
            .list();
    }

    @Override
    public List<String> getCurrentGroups() {
        // 获取当前企业id，角色id
        // 获取当前登陆的用户和企业信息
        Long userId = JwtUtil.getCurrentUserId();
        Long entId = enterpriseService.getCurrentEntIdByUserId(userId);
        // 获取企业
        Enterprise enterprise = enterpriseService.getById(entId);
        // 角色可能有多个
        Set<Long> roleIds = userService.getUserRoleIdsByUserId(userId,entId);
        return WorkFlowUtils.getCandidateGroups(enterprise, roleIds);
    }
}
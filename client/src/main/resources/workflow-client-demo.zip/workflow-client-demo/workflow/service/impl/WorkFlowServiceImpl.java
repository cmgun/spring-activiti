package com.jdh.invoice.workflow.service.impl;

import com.baomidou.mybatisplus.core.toolkit.CollectionUtils;
import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.google.common.collect.Lists;
import com.jdh.fuhsi.api.common.PageResult;
import com.jdh.fuhsi.api.common.Response;
import com.jdh.fuhsi.api.common.TaskContext;
import com.jdh.fuhsi.api.enums.SourceEnum;
import com.jdh.fuhsi.api.model.*;
import com.jdh.fuhsi.api.model.Process;
import com.jdh.fuhsi.api.service.ActHistoryService;
import com.jdh.fuhsi.api.service.ActProcessService;
import com.jdh.fuhsi.api.service.ActTaskService;
import com.jdh.invoice.common.idworker.SnowFlakeIdWorker;
import com.jdh.invoice.common.jwt.JwtUtil;
import com.jdh.invoice.user.model.dto.UserDTO;
import com.jdh.invoice.user.model.entity.Roles;
import com.jdh.invoice.user.service.IRolesService;
import com.jdh.invoice.user.service.IUserService;
import com.jdh.invoice.workflow.enums.ProcessEnum;
import com.jdh.invoice.workflow.model.dto.ProcessDetailDTO;
import com.jdh.invoice.workflow.model.dto.ProcessGlobalDTO;
import com.jdh.invoice.workflow.model.dto.ProcessHistoryDTO;
import com.jdh.invoice.workflow.model.dto.TaskListDTO;
import com.jdh.invoice.workflow.model.entity.ActIdentity;
import com.jdh.invoice.workflow.model.parm.TaskAuditPARM;
import com.jdh.invoice.workflow.model.parm.TaskListPARM;
import com.jdh.invoice.workflow.service.IWorkFlowService;
import com.jdh.invoice.workflow.utils.WorkFlowUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * 流程引擎通用服务接口
 *
 * @author chenqilin
 * @date 2019/8/20
 */
@Slf4j
@Service
public class WorkFlowServiceImpl implements IWorkFlowService {

    @Autowired
    private ActProcessService actProcessService;
    @Autowired
    private ActTaskService actTaskService;
    @Autowired
    private ActHistoryService actHistoryService;
    @Autowired
    private IUserService userService;
    @Autowired
    private IRolesService rolesService;

    @Autowired
    private SnowFlakeIdWorker idWorker;

    @Override
    public Response<Process> startProcess(String businessKey, ProcessGlobalDTO processGlobalDTO, ProcessEnum processEnum, ActIdentity identity) {
        // 构建请求
        TaskContext taskContext = new TaskContext();
        taskContext.setCandidateGroups(identity.getIdentityValue());
        // 回填用户名称
        UserDTO userDTO = null;
        try {
            userDTO = userService.getDtoById(processGlobalDTO.getUserId());
        } catch (Exception e) {
            // 如果为空则不填用户信息
            log.info("开启流程的用户信息为空，不填充用户信息");
        }
        processGlobalDTO.setUserName(userDTO != null ? userDTO.getUserName() : "");
        taskContext.setGlobalPayload(processGlobalDTO);

        ProcessStartRequest request = ProcessStartRequest.builder()
            .businessKey(businessKey)
            .category(processEnum.getCategory())
            .processDefinitionKey(processEnum.getDefId())
            .taskContext(taskContext)
            .build();
        request.setRequestNo(idWorker.nextId().toString());
        request.setSource(SourceEnum.INVOICE_LOAN.getCode());
        log.info("流程开启，发送请求给流程引擎，申请编号:{}，请求:{}", businessKey, request);
        Response<Process> response = actProcessService.start(request);
        log.info("流程开启，流程引擎响应结果，申请编号:{}，响应:{}", businessKey, response);
        return response;
    }

    @Override
    public Response<Void> endProcess(String processInstanceId, String reason) {
        log.info("流程终止，发送请求给流程引擎，processInstanceId:{}", processInstanceId);
        Response<Void> response = actProcessService.endProcess(processInstanceId, reason);
        log.info("流程终止，流程引擎响应结果，processInstanceId:{}，响应:{}", processInstanceId, response);
        return response;
    }

    /**
     * 获取流程激活的任务
     * @param businessKey 业务key
     * @param processDefinitionKey 流程定义id
     * @return 激活的任务
     */
    @Override
    public List<Task> getActiveTaskByBusinessKey(String businessKey, String processDefinitionKey) {
        ProcessActiveTaskRequest request = ProcessActiveTaskRequest.builder()
            .businessKey(businessKey)
            .processDefinitionKey(processDefinitionKey)
            .build();
        try {
            Response<List<Task>> response = actProcessService.processActiveTasks(request);
            if (response != null && Response.OK.equals(response.getCode())) {
                return response.getPayload();
            }
        } catch (RuntimeException e) {
            log.warn("查询流程激活任务失败，查询条件:{}", request, e);
        }
        return Lists.newArrayList();
    }

    /**
     * 查询待办任务
     *
     * @param candidateGroups 用户组
     * @param page 分页信息
     * @param queryParm 查询条件
     */
    @Override
    public Page<TaskListDTO> getToDoList(List<String> candidateGroups, Page<TaskListDTO> page, TaskListPARM queryParm) {
        ToDoTaskRequest request = ToDoTaskRequest.builder()
            .candidateGroup(candidateGroups)
            .taskCreateTimeBegin(queryParm.getCreateTimeStart())
            .taskCreateTimeEnd(queryParm.getCreateTimeEnd())
            .taskId(queryParm.getTaskId())
            .procCategory(queryParm.getProcCategory())
            .build();
        // 填充分页信息
        if (page != null) {
            request.setPageNo((int) page.getCurrent());
            request.setPageSize((int) page.getSize());
        } else {
            // 不需要分页查询
            request.setQueryAll(true);
            request.setPageNo(1);
            request.setPageSize(1);
        }
        log.info("查询待办任务，发送请求给流程引擎，请求:{}", request);
        Response<PageResult<Task>> response = actTaskService.todoList(request);
        log.info("查询待办任务，发送请求给流程引擎，响应:{}", response);
        if (response != null && Response.OK.equals(response.getCode())) {
            if (CollectionUtils.isNotEmpty(response.getPayload().getData())) {
                page.setRecords(response.getPayload().getData().stream().map(e -> new TaskListDTO(e, true)).collect(Collectors.toList()));
            }
            // 查询成功
            page.setTotal(response.getPayload().getTotal());
        }
        return page;
    }

    @Override
    public List<TaskListDTO> getAutoToDoList(String procCategory, String taskDefKey, Page page) {
        ToDoTaskRequest request = ToDoTaskRequest.builder()
            .candidateGroup(Lists.newArrayList(WorkFlowUtils.AUTO_CANDIDATE_GROUP))
            .procCategory(procCategory)
            .taskDefinitionKey(taskDefKey)
            .build();
        // 填充分页信息
        if (page != null) {
            request.setPageNo((int) page.getCurrent());
            request.setPageSize((int) page.getSize());
        } else {
            // 不需要分页查询
            request.setQueryAll(true);
            request.setPageNo(1);
            request.setPageSize(1);
        }
        log.info("查询自动审批待办任务，发送请求给流程引擎，请求:{}", request);
        Response<PageResult<Task>> response = actTaskService.todoList(request);
        log.info("查询自动审批待办任务，发送请求给流程引擎，响应:{}", response);
        if (response != null && Response.OK.equals(response.getCode())) {
            if (CollectionUtils.isNotEmpty(response.getPayload().getData())) {
                return response.getPayload().getData().stream().map(e -> new TaskListDTO(e, true)).collect(Collectors.toList());
            }
        }
        return Lists.newArrayList();
    }

    /**
     * 查询经办任务
     *
     * @param candidateGroups 用户组
     * @param page            分页信息
     * @param queryParm       查询条件
     */
    @Override
    public Page<TaskListDTO> getHistoryList(List<String> candidateGroups, Page<TaskListDTO> page, TaskListPARM queryParm) {
        HistoryQueryRequest request = HistoryQueryRequest.builder()
            .candidateGroup(candidateGroups)
            .taskCreateTimeBegin(queryParm.getCreateTimeStart())
            .taskCreateTimeEnd(queryParm.getCreateTimeEnd())
            .procCategory(queryParm.getProcCategory())
            .taskId(queryParm.getTaskId())
            .build();
        if (queryParm.getActive() != null) {
            request.setCompleteTask(!queryParm.getActive());
        }
        // 填充分页信息
        if (page != null) {
            request.setPageNo((int) page.getCurrent());
            request.setPageSize((int) page.getSize());
        } else {
            // 不需要分页查询
            page = new Page<>();
            request.setQueryAll(true);
        }
        // 请求
        log.info("查询经办任务，发送请求给流程引擎，请求:{}", request);
        Response<PageResult<History>> response = actHistoryService.query(request);
        log.info("查询经办任务，发送请求给流程引擎，响应:{}", response);
        if (response != null && Response.OK.equals(response.getCode())) {
            if (CollectionUtils.isNotEmpty(response.getPayload().getData())) {
                page.setRecords(response.getPayload().getData().stream().map(TaskListDTO::new).collect(Collectors.toList()));
            }
            // 查询成功
            page.setTotal(response.getPayload().getTotal());
        }
        return page;
    }

    /**
     * 查询流程详情
     */
    @Override
    public ProcessDetailDTO getProcessDetail(String processId) {
        log.info("查询流程详情，发送请求给流程引擎，请求:{}", processId);
        Response<List<History>> response = actHistoryService.queryProcessHistory(processId, false);
        log.info("查询流程详情，发送请求给流程引擎，响应:{}", response);
        // 任务列表
        List<ProcessHistoryDTO> history = Lists.newArrayList();
        // 流程中的任务id
        List<String> activeTaskIds = Lists.newArrayList();
        if (response != null && Response.OK.equals(response.getCode())) {
            if (CollectionUtils.isNotEmpty(response.getPayload())) {
                history = response.getPayload().stream().map(e -> new ProcessHistoryDTO(e, activeTaskIds)).collect(Collectors.toList());
            }
        }

        // 封装结果
        ProcessDetailDTO result = new ProcessDetailDTO();
        result.setHistory(history);
        result.setIsActive(false);
        // 获取当前处理人
        if (CollectionUtils.isNotEmpty(activeTaskIds)) {
            result.setIsActive(true);
            List<String> roleNames = getTaskCandidateRoleNames(activeTaskIds);
            result.setCurrentGroups(String.join(",", roleNames));
        }
        return result;
    }

    /**
     * 根据任务id获取对应的参与角色名称
     *
     * @param taskIds 任务id
     * @return 角色名称列表
     */
    private List<String> getTaskCandidateRoleNames(List<String> taskIds) {
        log.info("查询任务权限列表，发送请求给流程引擎，请求:{}", taskIds);
        Response<List<TaskIdentity>> response = actTaskService.queryIdentityLink(taskIds);
        log.info("查询任务权限列表，发送请求给流程引擎，响应:{}", response);
        if (response != null && Response.OK.equals(response.getCode())) {
            if (CollectionUtils.isNotEmpty(response.getPayload())) {
                // 获取角色名称
                return response.getPayload().stream().map(e -> {
                    Long roleId = WorkFlowUtils.getRoleIdFromGroups(e.getGroupId());
                    if (roleId != null) {
                        Roles roles = rolesService.getById(roleId);
                        return roles != null ? roles.getRoleName() : "";
                    }
                    return "";
                }).filter(StringUtils::isNotEmpty).collect(Collectors.toList());
            }
        }
        return Lists.newArrayList();
    }

    /**
     * 任务审批
     *
     * @param taskAuditPARM 任务审批参数
     * @param identity 下个任务节点权限信息
     * @return 响应结果
     */
    @Override
    public Response auditTask(TaskAuditPARM taskAuditPARM, ActIdentity identity, boolean isAutoTask) {
        // 获取当前用户id，用户名称
        Long userId = isAutoTask ? 0L : JwtUtil.getCurrentUserId();
        // 回填用户名称
        UserDTO userDTO = null;
        if (!isAutoTask) {
            userDTO = userService.getDtoById(userId);
        }
        String userName = userDTO != null ? userDTO.getUserName() : "系统自动审批";

        TaskAuditRequest request = TaskAuditRequest.builder()
            .taskId(taskAuditPARM.getTaskId())
            .candidateGroup(taskAuditPARM.getCandidateGroups())
            .auditor(userId.toString())
            .auditorName(userName)
            .comment(taskAuditPARM.getComment())
            .auditResult(taskAuditPARM.getAuditResult())
            .build();
        request.setRequestNo(idWorker.nextId().toString());
        request.setSource(SourceEnum.INVOICE_LOAN.getCode());
        if (identity != null) {
            // 设置下个节点权限信息
            TaskContext taskContext = new TaskContext();
            taskContext.setCandidateGroups(identity.getIdentityValue());
            request.setTaskContext(taskContext);
        }
        log.info("任务审批，发送请求给流程引擎，请求:{}", request);
        Response response = actTaskService.audit(request);
        log.info("任务审批，流程引擎响应结果，响应:{}", response);
        return response;
    }

    @Override
    public History queryHistoryDetail(String taskId) {
        log.info("查询历史任务详情，发送请求给流程引擎，请求:{}", taskId);
        Response<History> response = actHistoryService.queryTaskHistory(taskId);
        log.info("查询历史任务详情，流程引擎响应结果，响应:{}", response);
        return response.getPayload();
    }

    @Override
    public Task queryTaskDetail(String taskId) {
        log.info("查询激活任务详情，发送请求给流程引擎，请求:{}", taskId);
        Response<Task> response = actTaskService.queryDetail(taskId);
        log.info("查询激活任务详情，流程引擎响应结果，响应:{}", response);
        return response.getPayload();
    }
}

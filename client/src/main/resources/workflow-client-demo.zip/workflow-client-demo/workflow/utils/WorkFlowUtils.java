package com.jdh.invoice.workflow.utils;

import com.google.common.collect.Lists;
import com.jdh.fuhsi.api.common.Response;
import com.jdh.fuhsi.api.model.Comment;
import com.jdh.fuhsi.api.model.Task;
import com.jdh.invoice.enterprise.model.entity.Enterprise;
import com.jdh.invoice.workflow.enums.AuditResultEnum;
import com.jdh.invoice.workflow.model.entity.ActIdentity;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Set;

/**
 * 流程引擎工具类
 *
 * @author chenqilin
 * @date 2019/8/20
 */
@Slf4j
public class WorkFlowUtils {

    /**
     * 用户组定义分隔符
     */
    public static final String GROUP_SEPERATOR = "-";

    /**
     * 权限值，特殊占位符，企业id
     */
    public static final String IDENTIY_KEY_ENTID = "{entId}";

    /**
     * 自动审批组
     */
    public static final String AUTO_CANDIDATE_GROUP = "0-0";

    /**
     * 是否成功响应
     *
     * @param response 响应
     * @return true/false
     */
    public static boolean isSuccessResponse(Response response) {
        return response != null && (Response.OK.equals(response.getCode()) || Response.REPEAT_BUSINESS.equals(response.getCode()));
    }

    /**
     * 参与用户组Key定义
     *
     * @param enterprise 企业
     * @param roleIds    角色id
     * @return key
     */
    public static List<String> getCandidateGroups(Enterprise enterprise, Set<Long> roleIds) {
        // 运营端企业默认为0
        Long entId = enterprise.isMgt() ? 0L : enterprise.getId();
        List<String> candidateGroups = Lists.newArrayList();
        for (Long roleId : roleIds) {
            candidateGroups.add(entId + GROUP_SEPERATOR + roleId);
        }
        return candidateGroups;
    }

    /**
     * 从用户组key中获取角色id
     *
     * @param candidateGroups 用户组key
     * @return 角色id
     */
    public static Long getRoleIdFromGroups(String candidateGroups) {
        String[] groups = candidateGroups.split(GROUP_SEPERATOR);
        if (groups.length < 2) {
            // 不符合条件的格式
            return null;
        }
        try {
            return Long.valueOf(groups[1]);
        } catch (RuntimeException e) {
            log.warn("从用户组中获取角色id失败，用户组:{}", candidateGroups, e);
        }
        return null;
    }

    /**
     * 获取任务列表中第一个任务的名称
     *
     * @param tasks 任务列表
     * @return 第一个任务的名称
     */
    public static String getFirstTaskName(List<Task> tasks) {
        if (CollectionUtils.isNotEmpty(tasks)) {
            // 目前只有一个激活任务
            Task task = tasks.get(0);
            return task.getTaskName();
        }
        return "";
    }

    /**
     * 获取备注
     *
     * @param comments 备注列表
     * @return 备注
     */
    public static String getHistoryComment(List<Comment> comments) {
        if (CollectionUtils.isEmpty(comments)) {
            return "";
        }
        // 目前只有一个审批人
        return comments.get(0).getComment();
    }

    /**
     * 替换权限值中的特殊占位符
     *
     * @param identityValue 权限值
     * @return 替换占位符后的权限值
     */
    public static String replaceSpecialKey(String identityValue, Long entId) {
        if (identityValue.contains(IDENTIY_KEY_ENTID)) {
            return identityValue.replace(IDENTIY_KEY_ENTID, entId.toString());
        }
        return identityValue;
    }

    /**
     * 是否自动审批用户id
     *
     * @param userId
     * @return
     */
    public static boolean isAutoTaskUser(Long userId) {
        return userId == null || userId.equals(0L);
    }

    /**
     * 根据subDefKey从流程权限列表中获取对应分支权限
     *
     * @param identityList
     * @param auditResultEnum
     * @return
     */
    public static ActIdentity getActIdentityBySubDefKey(List<ActIdentity> identityList, AuditResultEnum auditResultEnum) {
        if (CollectionUtils.isEmpty(identityList)) {
            return null;
        }
        ActIdentity identity = null;
        // 查看是否有符合defSubId的记录
        for (ActIdentity actIdentity : identityList) {
            if (StringUtils.equals(auditResultEnum.getValue(), actIdentity.getDefSubId())) {
                identity = actIdentity;
                break;
            }
        }
        if (identity == null) {
            // 没有符合的记录，取第一条
            identity = identityList.get(0);
        }
        return identity;
    }
}
